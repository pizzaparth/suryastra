# SolarShield-NavIC: presentation dashboard

A replay of the May 10–11, 2024 geomagnetic superstorm with a semi-3D scene and a live metrics panel. It is frontend only: the model outputs come from a JSON file (`src/data/scenario_may2024.json`), so the real models can be dropped in later without touching the UI.

## Run it

**On the day, offline:** double-click `dist/index.html`. It is one self-contained file (code, fonts and data inlined), so it needs no server and no internet.

**While developing:**

```bash
cd frontend
npm install        # once, needs internet
npm run dev        # http://localhost:5173, reloads on save
npm run build      # rebuilds dist/index.html
```

## Presenting

| Control | What it does |
|---|---|
| Play / Pause, or Space | Plays the full story, about 90 s at 1× |
| 1× / 5× / 20× | Playback speed |
| Chapter bands above the timeline | Jump to a chapter |
| Click or drag the timeline | Scrub (stays in the current chapter where it can) |
| Drag the 3D view | Rotate up to about 30° away from the scripted shot |
| Mouse wheel on the 3D view | Zoom in or out |

URL shortcuts for rehearsing a moment: `index.html?ch=2&h=7.5` (chapter 2, 18:30 UTC). `h` is hours since 2024-05-10 11:00 UTC.

## The story

| Chapter | Timeline | What happens |
|---|---|---|
| 1. The storm reaches Earth | 11:00 → 20:00 UTC, 10 May | CME passes Aditya-L1, hits at 17:05, magnetopause is pushed inside geostationary orbit |
| 2. Warning one hour ahead | rewinds to 17:00 → 02:00 UTC | M1 forecasts Dst 1 h ahead; the first red alert goes out at 18:00, an hour before Dst crosses −50 nT |
| 3. From error forecast to alert | zooms into 02:00–02:30 UTC (30 s steps), then runs to 18:00 UTC, 11 May | LightGBM station forecast, M2 NavIC error, rule engine decisions |

## What is real and what is mock

| Data | Status | Source |
|---|---|---|
| Hourly solar wind (Bz, density, speed, pressure) and Dst | **Real** | `scripts/omni_may2024.txt`, cut from `data/raw/omni2_*.lst` |
| M1 accuracy table | **Real** | outputs of `notebooks/m1_storm_predictor.ipynb` |
| LightGBM accuracy | **Real** | `models/gnss_model/lgbm_c3_h10_meta.json` |
| Magnetopause distance | **Computed** | Shue et al. (1998) formula applied to the real pressure and Bz |
| M1 forecasts, M2 errors, LightGBM c3 series | **Mock** | `scripts/build_mock.mjs`, shaped like the real models |

The header shows a "Model outputs are mock data" badge until the real export replaces the mock.

## Swapping in real model outputs

Write `src/data/scenario_may2024.json` from Python following [DATA_CONTRACT.md](DATA_CONTRACT.md), set `meta.mock` to `false`, and run `npm run build`. Nothing in `src/` needs to change.

## Changing the alert rules

Edit `src/config/alert_rules.json`. Levels are checked top to bottom and the first match wins. Conditions can be combined with `all` / `any`. Save while `npm run dev` is running to see it live, or run `npm run build`.

## Files

```
frontend/
├── index.html
├── src/
│   ├── main.js              # wires scene, panel, timeline; per-frame state
│   ├── styles.css
│   ├── config/alert_rules.json
│   ├── data/                # scenario JSON (model outputs) + globe dots
│   ├── engine/
│   │   ├── story.js         # timeline, chapters, playback, data access, Shue model
│   │   └── alerts.js        # rule-based alert algorithm (reads alert_rules.json)
│   ├── scene/scene.js       # Three.js engine
│   └── ui/                  # panel, charts, timeline
├── scripts/build_mock.mjs   # regenerates the mock scenario + globe dots
└── dist/index.html          # offline build
```
