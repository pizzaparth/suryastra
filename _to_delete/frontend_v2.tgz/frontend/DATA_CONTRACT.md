# Data contract: `src/data/scenario_may2024.json`

The dashboard reads only this file. A Python export that writes the same shape replaces the mock data with no frontend changes. Times are ISO 8601 UTC strings.

## Top level

```jsonc
{
  "meta": { "title": "...", "contract_version": 1, "mock": true, ... },
  "timeline": { "start": "2024-05-10T11:00:00.000Z", "end": "...", "step_hours": 1, "impact": "2024-05-10T17:05:00.000Z" },
  "hourly": [ /* one row per hour, see below */ ],
  "m1_metrics": { /* accuracy table, see below */ },
  "m2_model": { "coeffs": [a, b, c], ... },
  "gnss": { /* station model window, see below */ },
  "sites": [ /* receivers and rescue zones */ ]
}
```

## `hourly[]`: M1 and M2, one row per hour

| Field | Meaning | Comes from |
|---|---|---|
| `t` | hour start | OMNI epoch |
| `inputs.bz`, `inputs.proton_density`, `inputs.sw_speed`, `inputs.dyn_pressure`, `inputs.dst_lag1` | M1's five features at hour `t` | `solarshield.data.omni.load_omni` + `m1_storm.build_dataset` |
| `dst_obs` | observed Dst at `t` (nT) | OMNI |
| `m1.forecast_for` | `t + 1 h` | |
| `m1.dst_pred` | `m1_storm.predict_dst_next(model, X)` for this row | M1 |
| `m1.dst_obs_at_target` | observed Dst at `t + 1 h` | OMNI |
| `m2.forecast_for` | `t + 1 h` | |
| `m2.navic_error_m` | NavIC error (m) from `m1.dst_pred`, including the time-of-day multiplier | M2 |
| `m2.base_error_m`, `m2.multiplier` | error before the multiplier, and the multiplier (1.0 or 1.5) | M2 |

The last row has `m1: null, m2: null` (no target hour inside the window). Alerts are computed in the browser from `m2.navic_error_m` and each site's `kind`.

## `m1_metrics`

`test_all_hours`, `test_storm_hours`, `persistence_all_hours`, `persistence_storm_hours`: each `{ r2, mae_nt, rmse_nt }`.
`may2024_window`: `{ model: {r2, mae_nt, rmse_nt, min_dst_nt}, persistence: {...}, observed_min_dst_nt }`.

## `gnss`: LightGBM station model

| Field | Meaning |
|---|---|
| `window_start` | first 30 s step (the 30-minute zoom starts here) |
| `step_seconds`, `horizon_steps` | 30 and 10 for `lgbm_c3_h10` |
| `display_station` | `id` of the site to highlight |
| `series[]` | 60 rows: `t`, `c3_obs`, `forecast_for` (`t + 5 min`), `c3_pred` (LightGBM), `c3_persistence` (= `c3_obs` at `t`), `c3_obs_at_target` |
| `metrics` | `lgbm_mae_m`, `persistence_mae_m`, `improvement_pct` |

## `sites[]`

`{ id, name, kind: "receiver" | "disaster", lat, lon, disaster_type? }`. `kind: "disaster"` sets `disaster_active` in the alert rules.

## Python export outline

```python
import json
from solarshield.data.omni import load_omni
from solarshield.models import m1_storm

df = m1_storm.build_dataset(load_omni())
window = df.loc["2024-05-10 11:00":"2024-05-11 18:00"]
model = m1_storm.load_model()
window = window.assign(dst_pred=m1_storm.predict_dst_next(model, window))
# ...build hourly rows, apply M2 to dst_pred, add gnss + sites, then:
# json.dump(scenario, open("frontend/src/data/scenario_may2024.json", "w"), indent=1)
```
