import "@fontsource-variable/archivo/wdth.css";
import "./styles.css";
import { StormScene } from "./scene/scene.js";
import { Panel } from "./ui/panel.js";
import { Timeline } from "./ui/timeline.js";
import {
  scenario,
  Playback,
  CHAPTERS,
  IMPACT_H,
  ZOOM,
  timeAt,
  observedAt,
  magnetopause,
  m2Error,
  alertsAt,
  forecastAt,
} from "./engine/story.js";

const $ = (s) => document.querySelector(s);
const hhmm = (d) => d.toISOString().slice(11, 16);

const scene = new StormScene($("#scene"), $("#labels"));
scene.setSites(scenario.sites);
const panel = new Panel($("#panel"));
const pb = new Playback();
const timeline = new Timeline($("#timeline"), pb);

window.addEventListener("resize", () => scene.resize());
window.addEventListener("keydown", (e) => {
  if (e.code === "Space" && e.target === document.body) {
    e.preventDefault();
    pb.toggle();
  }
});

// ---------- caption, callouts, transition flash ----------
function setCaption(n) {
  const c = CHAPTERS[n - 1];
  $("#caption").innerHTML = `<div class="num">Chapter <b>${c.n}</b> of 3</div><h2>${c.title}</h2><p>${c.lede}</p>`;
}

function flash(title, sub) {
  const el = $("#flash");
  el.hidden = false;
  el.innerHTML = `<span>${title}<small>${sub}</small></span>`;
  el.style.animation = "none";
  void el.offsetWidth;
  el.style.animation = "";
  clearTimeout(flash.t);
  flash.t = setTimeout(() => (el.hidden = true), 2500);
}

let lastCallouts = "";
function setCallouts(st) {
  const items = [];
  if (st.chapter === 1) {
    const sinceL1 = st.h - (IMPACT_H - 0.75);
    if (sinceL1 > 0 && st.h < IMPACT_H + 0.5)
      items.push(`<div class="callout"><strong>Shock detected at Aditya-L1</strong>About 45 minutes before it reaches Earth.</div>`);
    if (st.mp.r0 < 6.6)
      items.push(
        `<div class="callout breach"><strong>Magnetopause at ${st.mp.r0.toFixed(1)} Rₑ</strong>Pushed inside geostationary orbit (6.6 Rₑ) on the Sun-facing side.</div>`
      );
  }
  if (st.chapter === 2) {
    const red = st.alerts.filter((a) => a.alert.id === "RED");
    const f = forecastAt(st.h);
    if (red.length)
      items.push(
        `<div class="callout alert"><strong>Red alert for ${red.length} rescue zone${red.length > 1 ? "s" : ""}</strong>Issued ${hhmm(timeAt(f.issuedH))} UTC for ${hhmm(timeAt(f.forH))} UTC, before the error arrives.</div>`
      );
  }
  if (st.chapter === 3 && st.zoom)
    items.push(`<div class="callout"><strong>Zoomed in to 30-second steps</strong>02:00–02:30 UTC on 11 May, at the storm's peak. The station model forecasts 5 minutes ahead.</div>`);
  const html = items.join("");
  if (html !== lastCallouts) {
    $("#callouts").innerHTML = html;
    lastCallouts = html;
  }
}

pb.on((type, p) => {
  if (type === "chapter") {
    scene.resetView();
    setCaption(p.chapter);
    if (p.chapter === 2 && p.playing) flash("Rewind to 17:00 UTC", "What the system knew before the storm hit");
    if (p.chapter === 3 && p.playing) flash("Zoom in at the storm's peak", "02:00 UTC, 30-second steps");
    panel.update(state(), true);
  }
  if (type === "segment" && !p.zoom) flash("Zoom out", "The storm recovers over the next 15 hours");
});
setCaption(1);

// ---------- state for one frame ----------
function state(dt = 0) {
  const h = pb.h;
  const date = timeAt(h);
  const obs = observedAt(h);
  const mp = magnetopause(obs.dyn_pressure, obs.bz);
  const storm = Math.min(1, Math.max(0, (-obs.dst - 15) / 330));
  return {
    h,
    dt,
    date,
    chapter: pb.chapter,
    zoom: pb.zoom,
    obs,
    mp,
    storm,
    impactH: IMPACT_H,
    truthError: m2Error(obs.dst, date),
    alerts: pb.chapter > 1 ? alertsAt(h) : null,
    focusSite: pb.chapter === 3 && pb.zoom ? scenario.gnss.display_station : null,
    snap: snapFrames > 0,
  };
}

let snapFrames = 0;
let last = performance.now();
let lastClock = "";
function frame(now) {
  const dt = (now - last) / 1000;
  last = now;
  pb.tick(dt);
  const st = state(dt);
  if (snapFrames > 0) snapFrames--;
  scene.update(st);
  if (pb.chapter > 1) panel.update(st);
  else panel.update({ ...st, alerts: [] });
  timeline.update(st);
  setCallouts(st);
  const clock = hhmm(st.date);
  if (clock !== lastClock) {
    lastClock = clock;
    $("#clock-utc").textContent = clock;
    $("#clock-ist").textContent = hhmm(new Date(st.date.getTime() + 5.5 * 36e5));
    $("#clock-date").textContent = st.date.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
  }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// for quick checks from the console / screenshots: ?h=7&ch=2
const q = new URLSearchParams(location.search);
if (q.has("ch")) pb.goChapter(Number(q.get("ch")));
if (q.has("h")) pb.scrub(Number(q.get("h")));
if (q.has("ch") || q.has("h")) snapFrames = 8;
if (q.has("play")) pb.toggle();
window.__pb = pb;
void ZOOM;
