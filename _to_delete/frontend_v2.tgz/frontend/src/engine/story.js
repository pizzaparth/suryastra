// Scenario access + the master timeline.
//
// Time is measured in "story hours" h: h = 0 is the first hourly row (2024-05-10 11:00 UTC).
// The three chapters are played as segments of that one timeline. Chapter 2 starts earlier than
// chapter 1 ends: that is the deliberate rewind ("we would have known an hour earlier").
import scenario from "../data/scenario_may2024.json";
import { classifyAlert } from "./alerts.js";

export { scenario };

const T0 = Date.parse(scenario.timeline.start);
export const H_END = scenario.hourly.length - 1;
export const IMPACT_H = (Date.parse(scenario.timeline.impact) - T0) / 36e5;
export const ZOOM = { from: (Date.parse(scenario.gnss.window_start) - T0) / 36e5 };
ZOOM.to = ZOOM.from + (scenario.gnss.series.length * scenario.gnss.step_seconds) / 3600;

export const CHAPTERS = [
  {
    n: 1,
    title: "The storm reaches Earth",
    lede: "A coronal mass ejection hits Earth's magnetic shield at 17:05 UTC. Solar wind pressure jumps tenfold and the shield is pushed in toward the satellites.",
  },
  {
    n: 2,
    title: "Warning one hour ahead",
    lede: "Rewind to 17:00 UTC. The storm model forecasts Dst one hour ahead, so receivers and rescue teams are alerted before positioning degrades.",
  },
  {
    n: 3,
    title: "From error forecast to alert",
    lede: "The error models turn the storm forecast into metres of positioning error, and the rule engine decides what each team should do.",
  },
];

// Seconds of wall-clock time each segment takes at 1x. Total = 90 s.
export const SEGMENTS = [
  { chapter: 1, from: 0, to: 9, secs: 24 },
  { chapter: 2, from: 6, to: ZOOM.from, secs: 24 },
  { chapter: 3, from: ZOOM.from, to: ZOOM.to, secs: 24, zoom: true },
  { chapter: 3, from: ZOOM.to, to: H_END, secs: 18 },
];

// Event markers are derived from the data, so they move if the model outputs change.
const minDst = Math.min(...scenario.hourly.map((r) => r.dst_obs));
export const EVENTS = [
  { h: IMPACT_H, label: "CME impact" },
  { h: scenario.hourly.findIndex((r, i) => r.m2 && alertsAt(i).some((a) => a.alert.id === "RED")), label: "First red alert" },
  { h: scenario.hourly.findIndex((r) => r.dst_obs < -50), label: "Dst below −50 nT" },
  { h: scenario.hourly.findIndex((r) => r.dst_obs === minDst), label: "Dst minimum" },
];

export const timeAt = (h) => new Date(T0 + h * 36e5);

const lerp = (a, b, t) => a + (b - a) * t;

// Observed values interpolated between hourly rows.
export function observedAt(h) {
  const hc = Math.min(Math.max(h, 0), H_END);
  const i = Math.min(Math.floor(hc), H_END - 1);
  const t = hc - i;
  const a = scenario.hourly[i];
  const b = scenario.hourly[i + 1];
  const out = {};
  for (const k of Object.keys(a.inputs)) out[k] = lerp(a.inputs[k], b.inputs[k], t);
  out.dst = lerp(a.dst_obs, b.dst_obs, t);
  return out;
}

// The latest forecast the system has issued at time h (issued on the hour, for the next hour).
export function forecastAt(h) {
  const i = Math.min(Math.max(Math.floor(h), 0), H_END - 1);
  const row = scenario.hourly[i];
  return { issuedH: i, forH: i + 1, m1: row.m1, m2: row.m2 };
}

// "Truth" error proxy used for the visual signal degradation: M2 applied to observed Dst.
const [A, B, C] = scenario.m2_model.coeffs;
export function m2Error(dst, date) {
  const base = Math.max(A * dst * dst + B * dst + C, 2);
  const ist = (date.getUTCHours() + date.getUTCMinutes() / 60 + 5.5) % 24;
  return base * (ist >= 18 || ist < 6 ? 1.5 : 1);
}

export function alertsAt(h) {
  const f = forecastAt(h);
  return scenario.sites.map((s) => ({
    site: s,
    error: f.m2.navic_error_m,
    alert: classifyAlert({ navic_error_m: f.m2.navic_error_m, disaster_active: s.kind === "disaster" }),
  }));
}

export function stormClass(dst) {
  if (dst > -30) return "Quiet";
  if (dst > -50) return "Weak storm";
  if (dst > -100) return "Moderate storm";
  if (dst > -250) return "Intense storm";
  return "Superstorm";
}

// Shue et al. (1998) magnetopause model, from dynamic pressure (nPa) and Bz (nT). Units: Earth radii.
export function magnetopause(p, bz) {
  const P = Math.max(p, 0.1);
  const r0 = (10.22 + 1.29 * Math.tanh(0.184 * (bz + 8.14))) * Math.pow(P, -1 / 6.6);
  const alpha = (0.58 - 0.007 * bz) * (1 + 0.024 * Math.log(P));
  return { r0, alpha };
}

// ---------- playback ----------
export class Playback {
  constructor() {
    this.seg = 0;
    this.h = 0;
    this.playing = false;
    this.speed = 1;
    this.listeners = new Set();
  }
  get segment() {
    return SEGMENTS[this.seg];
  }
  get chapter() {
    return SEGMENTS[this.seg].chapter;
  }
  get zoom() {
    return Boolean(SEGMENTS[this.seg].zoom);
  }
  on(fn) {
    this.listeners.add(fn);
  }
  emit(type) {
    for (const fn of this.listeners) fn(type, this);
  }
  setSpeed(s) {
    this.speed = s;
    this.emit("speed");
  }
  toggle() {
    if (!this.playing && this.seg === SEGMENTS.length - 1 && this.h >= H_END) this.goChapter(1);
    this.playing = !this.playing;
    this.emit("play");
  }
  goChapter(n) {
    this.seg = SEGMENTS.findIndex((s) => s.chapter === n);
    this.h = SEGMENTS[this.seg].from;
    this.emit("chapter");
  }
  // Scrubbing keeps the current chapter when its segments contain h.
  scrub(h) {
    h = Math.min(Math.max(h, 0), H_END);
    const cur = this.chapter;
    let idx = SEGMENTS.findIndex((s) => s.chapter === cur && h >= s.from && h <= s.to);
    if (idx < 0) idx = SEGMENTS.findIndex((s) => h >= s.from && h <= s.to);
    const changed = idx !== this.seg && SEGMENTS[idx].chapter !== cur;
    this.seg = idx;
    this.h = h;
    this.emit(changed ? "chapter" : "scrub");
  }
  tick(dt) {
    if (!this.playing) return;
    const s = SEGMENTS[this.seg];
    this.h += ((s.to - s.from) / s.secs) * dt * this.speed;
    if (this.h >= s.to) {
      if (this.seg < SEGMENTS.length - 1) {
        const prevChapter = s.chapter;
        this.seg += 1;
        this.h = SEGMENTS[this.seg].from;
        this.emit(SEGMENTS[this.seg].chapter !== prevChapter ? "chapter" : "segment");
      } else {
        this.h = s.to;
        this.playing = false;
        this.emit("play");
      }
    }
  }
}
