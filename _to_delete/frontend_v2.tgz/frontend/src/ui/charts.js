import { Chart, LineController, LineElement, PointElement, LinearScale, Tooltip } from "chart.js";

Chart.register(LineController, LineElement, PointElement, LinearScale, Tooltip);

export const SERIES = {
  observed: "#eef0ff",
  model: "#3987e5",
  baseline: "#8a93bd",
  grid: "#1a2560",
  tick: "#7480b8",
};

Chart.defaults.font.family = '"Archivo Variable", system-ui, sans-serif';
Chart.defaults.font.size = 12;
Chart.defaults.color = SERIES.tick;
Chart.defaults.animation = false;

// Draws a horizontal reference line, a playhead, and dims everything right of the playhead.
const overlay = {
  id: "overlay",
  afterDatasetsDraw(chart, _args, opts) {
    const { ctx, chartArea: a, scales } = chart;
    ctx.save();
    if (opts.refY != null) {
      const y = scales.y.getPixelForValue(opts.refY);
      ctx.strokeStyle = "rgba(236,131,90,0.75)";
      ctx.setLineDash([3, 4]);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(a.left, y);
      ctx.lineTo(a.right, y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "#e9a184";
      ctx.textAlign = "right";
      ctx.fillText(opts.refLabel, a.right - 4, y - 5);
    }
    if (opts.playX != null) {
      const x = scales.x.getPixelForValue(opts.playX);
      ctx.fillStyle = "rgba(10,18,54,0.55)";
      ctx.fillRect(x, a.top, a.right - x, a.bottom - a.top);
      ctx.strokeStyle = "rgba(238,240,255,0.85)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(x, a.top);
      ctx.lineTo(x, a.bottom);
      ctx.stroke();
    }
    ctx.restore();
  },
};
Chart.register(overlay);

const tooltip = {
  backgroundColor: "rgba(6,12,40,0.95)",
  borderColor: "#2c3a80",
  borderWidth: 1,
  titleColor: "#eef0ff",
  bodyColor: "#b0b9e4",
  padding: 10,
  displayColors: true,
  boxWidth: 10,
  boxHeight: 2,
  mode: "nearest",
  axis: "x",
  intersect: false,
};

function lineDataset(label, color, dash) {
  return {
    label,
    data: [],
    borderColor: color,
    backgroundColor: color,
    borderWidth: 2,
    borderDash: dash ? [6, 4] : [],
    pointRadius: (c) => (c.dataIndex === c.dataset.data.length - 1 ? 4 : 0),
    pointHoverRadius: 5,
    pointBorderWidth: 2,
    pointBorderColor: "#0a1236",
    tension: 0.25,
    spanGaps: true,
  };
}

export function dstChart(canvas, { xMax, fmtX }) {
  return new Chart(canvas, {
    type: "line",
    data: { datasets: [lineDataset("Observed Dst", SERIES.observed), lineDataset("M1 forecast (+1 h)", SERIES.model, true)] },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      parsing: false,
      interaction: { mode: "nearest", axis: "x", intersect: false },
      layout: { padding: { top: 6, right: 4 } },
      scales: {
        x: {
          type: "linear",
          min: 0,
          max: xMax,
          grid: { color: SERIES.grid, drawTicks: false },
          border: { display: false },
          ticks: { stepSize: 6, callback: fmtX, padding: 6 },
        },
        y: {
          min: -460,
          max: 90,
          grid: { color: SERIES.grid, drawTicks: false },
          border: { display: false },
          ticks: { stepSize: 100, padding: 6, callback: (v) => `${v}`.replace("-", "−") },
          title: { display: true, text: "nT", color: SERIES.tick },
        },
      },
      plugins: {
        legend: { display: false },
        overlay: { refY: -50, refLabel: "Storm level, −50 nT" },
        tooltip: {
          ...tooltip,
          callbacks: {
            title: (items) => (items[0] ? `${fmtX(items[0].parsed.x)} UTC` : ""),
            label: (i) => ` ${i.dataset.label}: ${Math.round(i.parsed.y)} nT`,
          },
        },
      },
    },
  });
}

export function gnssChart(canvas, { xMax, fmtX, yMin, yMax }) {
  return new Chart(canvas, {
    type: "line",
    data: {
      datasets: [
        lineDataset("Observed", SERIES.observed),
        lineDataset("LightGBM forecast", SERIES.model, true),
        { ...lineDataset("Persistence", SERIES.baseline, true), borderWidth: 1.5 },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      parsing: false,
      interaction: { mode: "nearest", axis: "x", intersect: false },
      scales: {
        x: {
          type: "linear",
          min: 0,
          max: xMax,
          grid: { color: SERIES.grid, drawTicks: false },
          border: { display: false },
          ticks: { stepSize: 10, callback: fmtX, padding: 6 },
        },
        y: {
          min: yMin,
          max: yMax,
          grid: { color: SERIES.grid, drawTicks: false },
          border: { display: false },
          ticks: { padding: 6, maxTicksLimit: 5, callback: (v) => v.toFixed(2).replace("-", "−") },
          title: { display: true, text: "m", color: SERIES.tick },
        },
      },
      plugins: {
        legend: { display: false },
        overlay: { refY: null },
        tooltip: {
          ...tooltip,
          callbacks: {
            title: (items) => (items[0] ? `${fmtX(items[0].parsed.x)} UTC` : ""),
            label: (i) => ` ${i.dataset.label}: ${i.parsed.y.toFixed(3)} m`,
          },
        },
      },
    },
  });
}

// Tiny inline SVG trend line. points = [[h, value], ...]; fixed x and y scales so growth is visible.
export function sparkPath(points, min, max, xMax, w = 120, h = 28) {
  if (points.length < 2) return { d: "", x: 0, y: h / 2 };
  const span = max - min || 1;
  const X = (t) => (t / xMax) * w;
  const Y = (v) => h - 2 - ((Math.min(max, Math.max(min, v)) - min) / span) * (h - 4);
  const d = points.map(([t, v], i) => `${i ? "L" : "M"}${X(t).toFixed(1)},${Y(v).toFixed(1)}`).join("");
  const [lt, lv] = points[points.length - 1];
  return { d, x: X(lt), y: Y(lv) };
}
