// Side panel: one Dst chart that stays across chapters, plus a block per chapter.
import { scenario, H_END, timeAt, observedAt, forecastAt, stormClass, ZOOM, alertsAt } from "../engine/story.js";
import { ALERT_LEVELS } from "../engine/alerts.js";
import { dstChart, gnssChart, sparkPath, SERIES } from "./charts.js";

const STATUS_VAR = { good: "var(--good)", warning: "var(--warning)", serious: "var(--serious)", critical: "var(--critical)" };
const hhmm = (d) => d.toISOString().slice(11, 16);
const fmtH = (h) => hhmm(timeAt(h));
const nt = (v) => `${v > 0 ? "+" : ""}${Math.round(v)}`.replace("-", "−");
const signed = (v, d = 1) => `${v.toFixed(d)}`.replace("-", "−");

const chip = (a) => `<span class="chip" data-status="${a.status}" style="--c:${STATUS_VAR[a.status]}">${a.label}</span>`;

const WIND = [
  { key: "sw_speed", label: "Solar wind speed", unit: "km/s", d: 0 },
  { key: "bz", label: "Magnetic field Bz", unit: "nT", d: 1, note: "negative = southward" },
  { key: "proton_density", label: "Proton density", unit: "n/cm³", d: 1 },
  { key: "dyn_pressure", label: "Dynamic pressure", unit: "nPa", d: 1 },
];

function range(key) {
  const vals = scenario.hourly.map((r) => (key === "dst" ? r.dst_obs : r.inputs[key]));
  return [Math.min(...vals), Math.max(...vals)];
}

function sparkSvg(id) {
  return `<svg viewBox="0 0 120 28" aria-hidden="true"><path id="${id}-p" fill="none" stroke="${SERIES.observed}" stroke-width="1.6" stroke-linejoin="round" opacity="0.85"/><circle id="${id}-c" r="3" fill="${SERIES.observed}"/></svg>`;
}

export class Panel {
  constructor(root) {
    this.root = root;
    root.innerHTML = `
      <section class="block" id="dst-block">
        <div class="block-head"><h3>Dst index</h3><span class="src">Observed from NASA OMNI, forecast from M1</span></div>
        <ul class="chart-legend">
          <li><i style="border-color:${SERIES.observed}"></i>Observed</li>
          <li id="leg-fc"><i class="dash" style="border-color:${SERIES.model}"></i>M1 forecast, 1 hour ahead</li>
        </ul>
        <div class="chart-wrap"><canvas id="dst-chart" role="img" aria-label="Dst index over the storm, observed and forecast"></canvas></div>
      </section>
      <div id="chapter-block"></div>`;
    this.chapterEl = root.querySelector("#chapter-block");
    this.dst = dstChart(root.querySelector("#dst-chart"), { xMax: H_END, fmtX: (v) => fmtH(v) });
    this.mode = null;
    this.ranges = Object.fromEntries([...WIND.map((w) => w.key), "dst"].map((k) => [k, range(k)]));
    this.lastChart = 0;
  }

  build(mode) {
    this.mode = mode;
    this.gnss?.destroy();
    this.gnss = null;
    if (mode === 1) this.chapterEl.innerHTML = this.ch1();
    if (mode === 2) this.chapterEl.innerHTML = this.ch2();
    if (mode === 3) this.chapterEl.innerHTML = this.ch3();
    if (mode === 3) {
      const ys = scenario.gnss.series.flatMap((s) => [s.c3_obs, s.c3_pred, s.c3_persistence]);
      const pad = 0.03;
      this.gnss = gnssChart(this.chapterEl.querySelector("#gnss-chart"), {
        xMax: scenario.gnss.series.length + scenario.gnss.horizon_steps,
        fmtX: (k) => new Date(Date.parse(scenario.gnss.window_start) + k * 30e3).toISOString().slice(11, 16),
        yMin: Math.floor((Math.min(...ys) - pad) * 20) / 20,
        yMax: Math.ceil((Math.max(...ys) + pad) * 20) / 20,
      });
    }
    this.root.scrollTop = 0;
  }

  ch1() {
    return `
      <section class="block">
        <div class="block-head"><h3>Solar wind</h3><span class="src">The storm model's inputs</span></div>
        <div class="rows">
          <div class="row wide"><span class="k">CME shock arrival</span><span class="v" id="v-cme">–</span></div>
          ${WIND.map((w) => `<div class="row"><span class="k">${w.label}${w.note ? `<br><small style="color:var(--ink-3);font-size:12px">${w.note}</small>` : ""}</span><span class="v" id="v-${w.key}">–</span>${sparkSvg(`s-${w.key}`)}</div>`).join("")}
        </div>
      </section>
      <section class="block">
        <div class="block-head"><h3>Earth's response</h3><span class="src">Observed</span></div>
        <div class="rows">
          <div class="row"><span class="k">Dst index <span id="v-class"></span></span><span class="v" id="v-dst">–</span>${sparkSvg("s-dst")}</div>
          <div class="row wide"><span class="k">Magnetopause distance</span><span class="v" id="v-mp">–</span></div>
        </div>
        <p class="note">Magnetopause distance from the Shue (1998) model using observed pressure and Bz. NavIC's geostationary satellites orbit at 6.6 Rₑ.</p>
      </section>`;
  }

  ch2() {
    const m = scenario.m1_metrics;
    const f = (x) => x.toFixed(1);
    return `
      <section class="block">
        <div class="block-head"><h3>Storm forecast</h3><span class="src">M1, XGBoost, 1 hour ahead</span></div>
        <div class="hero">
          <span class="k" id="fc-k">Forecast Dst</span>
          <div><span class="lead">1 hour ahead</span><div class="big" id="fc-v">–</div></div>
          <div class="side">Observed now<b id="fc-obs">–</b></div>
        </div>
        <div class="issued" id="issued">
          <span class="when" id="issued-when">–</span>
          <div class="chips" id="issued-chips"></div>
        </div>
      </section>
      <section class="block">
        <div class="block-head"><h3>How good is M1?</h3><span class="src">Mean absolute error, nT</span></div>
        <table class="acc">
          <thead><tr><th>Period</th><th>M1</th><th>Persistence</th></tr></thead>
          <tbody>
            <tr><td>Test set 2021–24, all hours</td><td class="better">${f(m.test_all_hours.mae_nt)}</td><td>${f(m.persistence_all_hours.mae_nt)}</td></tr>
            <tr><td>Test set, storm hours (Dst &lt; −50)</td><td class="better">${f(m.test_storm_hours.mae_nt)}</td><td>${f(m.persistence_storm_hours.mae_nt)}</td></tr>
            <tr><td>This storm, May 9–14 2024</td><td>${f(m.may2024_window.model.mae_nt)}</td><td class="better">${f(m.may2024_window.persistence.mae_nt)}</td></tr>
          </tbody>
        </table>
        <p class="note">Persistence assumes Dst stays the same for the next hour. Test R² ${m.test_all_hours.r2.toFixed(3)} on all hours, ${m.test_storm_hours.r2.toFixed(3)} on storm hours.</p>
        <p class="note warn">On this storm M1 is slightly worse than persistence and overshoots the minimum (${nt(m.may2024_window.model.min_dst_nt)} nT forecast, ${nt(m.may2024_window.observed_min_dst_nt)} nT observed).</p>
      </section>`;
  }

  ch3() {
    const g = scenario.gnss;
    const site = scenario.sites.find((s) => s.id === g.display_station);
    return `
      <section class="block">
        <div class="block-head"><h3>Station error forecast</h3><span class="src">LightGBM, 5 min ahead, ${site.name} demo station</span></div>
        <ul class="chart-legend">
          <li><i style="border-color:${SERIES.observed}"></i>Observed</li>
          <li><i class="dash" style="border-color:${SERIES.model}"></i>LightGBM forecast</li>
          <li><i class="dash" style="border-color:${SERIES.baseline}"></i>Persistence</li>
        </ul>
        <div class="chart-wrap small"><canvas id="gnss-chart" role="img" aria-label="Station vertical error: observed, LightGBM forecast and persistence"></canvas></div>
        <p class="note">Test-set mean error <b style="color:#7fe08a">${g.metrics.lgbm_mae_m.toFixed(4)} m</b> vs ${g.metrics.persistence_mae_m.toFixed(4)} m for persistence, ${g.metrics.improvement_pct.toFixed(1)}% lower. ${g.station_note}</p>
      </section>
      <section class="block">
        <div class="block-head"><h3>NavIC positioning error</h3><span class="src">M2, polynomial from plan.md</span></div>
        <div class="rows">
          <div class="row wide"><span class="k"><span id="m2-k">Forecast error over India</span><br><small class="note" id="m2-note"></small></span><span class="v big-v" id="m2-v">–</span></div>
        </div>
      </section>
      <section class="block">
        <div class="block-head"><h3>Alert decisions</h3><span class="src">Rule engine, alert_rules.json</span></div>
        <div class="decisions" id="decisions"></div>
      </section>`;
  }

  setSpark(id, key, h) {
    const pts = [];
    for (let i = 0; i <= Math.floor(h); i++) pts.push([i, key === "dst" ? scenario.hourly[i].dst_obs : scenario.hourly[i].inputs[key]]);
    const o = observedAt(h);
    pts.push([h, key === "dst" ? o.dst : o[key]]);
    const [mn, mx] = this.ranges[key];
    const s = sparkPath(pts, mn, mx, H_END);
    const p = this.chapterEl.querySelector(`#${id}-p`);
    if (!p) return;
    p.setAttribute("d", s.d);
    const c = this.chapterEl.querySelector(`#${id}-c`);
    c.setAttribute("cx", s.x);
    c.setAttribute("cy", s.y);
  }

  set(id, html) {
    const el = this.chapterEl.querySelector(`#${id}`);
    if (el && el.innerHTML !== html) el.innerHTML = html;
  }

  update(st, force = false) {
    const now = performance.now();
    if (!force && now - this.lastChart < 90) return;
    this.lastChart = now;
    if (st.chapter !== this.mode) {
      this.build(st.chapter);
      this.root.dataset.ch = st.chapter;
    }
    this.updateDst(st);
    if (st.chapter === 1) this.updateCh1(st);
    if (st.chapter === 2) this.updateCh2(st);
    if (st.chapter === 3) this.updateCh3(st);
  }

  updateDst(st) {
    const obs = [];
    for (let i = 0; i <= Math.floor(st.h); i++) obs.push({ x: i, y: scenario.hourly[i].dst_obs });
    obs.push({ x: st.h, y: st.obs.dst });
    const fc = [];
    if (st.chapter > 1) {
      for (let i = 0; i <= Math.min(Math.floor(st.h), H_END - 1); i++) {
        const r = scenario.hourly[i];
        if (r.m1) fc.push({ x: i + 1, y: r.m1.dst_pred });
      }
    }
    this.dst.data.datasets[0].data = obs;
    this.dst.data.datasets[1].data = fc;
    this.dst.options.plugins.overlay.playX = st.h;
    this.dst.update("none");
    this.root.querySelector("#leg-fc").style.opacity = st.chapter > 1 ? 1 : 0.35;
  }

  updateCh1(st) {
    const o = st.obs;
    const dh = st.impactH - st.h;
    const hm = (x) => `${Math.floor(x)} h ${String(Math.floor((x % 1) * 60)).padStart(2, "0")} min`;
    this.set("v-cme", dh > 0 ? `in ${hm(dh)}` : `arrived ${hm(-dh)} ago`);
    for (const w of WIND) {
      this.set(`v-${w.key}`, `${w.key === "bz" ? signed(o[w.key], w.d) : o[w.key].toFixed(w.d)}<small>${w.unit}</small>`);
      this.setSpark(`s-${w.key}`, w.key, st.h);
    }
    this.set("v-dst", `${nt(o.dst)}<small>nT</small>`);
    this.set("v-class", `<br><small style="color:var(--ink-3);font-size:12px">${stormClass(o.dst)}</small>`);
    this.setSpark("s-dst", "dst", st.h);
    const inside = st.mp.r0 < 6.6;
    this.set("v-mp", `<span style="color:${inside ? "var(--solar)" : "inherit"}">${st.mp.r0.toFixed(1)}</span><small>Rₑ${inside ? ", inside GEO" : ""}</small>`);
  }

  updateCh2(st) {
    const f = forecastAt(st.h);
    this.set("fc-k", `Forecast Dst for ${fmtH(f.forH)} UTC, issued ${fmtH(f.issuedH)}`);
    this.set("fc-v", `${nt(f.m1.dst_pred)}<small>nT</small>`);
    this.set("fc-obs", `${nt(st.obs.dst)} nT`);
    const counts = {};
    for (const a of st.alerts) counts[a.alert.id] = (counts[a.alert.id] || 0) + 1;
    const firstRedH = scenario.hourly.findIndex((r, i) => i <= Math.floor(st.h) && r.m2 && alertsAt(i).some((a) => a.alert.id === "RED"));
    const crossH = scenario.hourly.findIndex((r) => r.dst_obs < -50);
    const lead = crossH - firstRedH;
    const when =
      firstRedH >= 0
        ? `First red alert issued <b>${fmtH(firstRedH)} UTC</b>${lead > 0 ? `, ${lead} h before observed Dst crossed −50 nT` : ""}`
        : `Latest alerts, issued <b>${fmtH(f.issuedH)} UTC</b> for ${fmtH(f.forH)} UTC`;
    this.set("issued-when", when);
    this.set(
      "issued-chips",
      ALERT_LEVELS.filter((l) => counts[l.id])
        .map((l) => `${chip(l)}<span style="color:var(--ink-2);font-size:13.5px;align-self:center">${counts[l.id]} site${counts[l.id] > 1 ? "s" : ""}</span>`)
        .join("")
    );
  }

  updateCh3(st) {
    const g = scenario.gnss;
    const k = st.zoom ? (st.h - ZOOM.from) * 120 : g.series.length;
    const n = Math.min(Math.floor(k), g.series.length - 1);
    const obs = [];
    const lg = [];
    const pe = [];
    for (let i = 0; i <= n; i++) {
      const s = g.series[i];
      obs.push({ x: i, y: s.c3_obs });
      lg.push({ x: i + g.horizon_steps, y: s.c3_pred });
      pe.push({ x: i + g.horizon_steps, y: s.c3_persistence });
    }
    if (this.gnss) {
      this.gnss.data.datasets[0].data = obs;
      this.gnss.data.datasets[1].data = lg;
      this.gnss.data.datasets[2].data = pe;
      this.gnss.options.plugins.overlay.playX = st.zoom ? Math.min(k, g.series.length) : null;
      this.gnss.update("none");
    }
    const f = forecastAt(st.h);
    this.set("m2-k", `Forecast error over India, ${fmtH(f.forH)} UTC`);
    this.set("m2-v", `${f.m2.navic_error_m.toFixed(1)}<small>m</small>`);
    this.set(
      "m2-note",
      `From forecast Dst ${nt(f.m1.dst_pred)} nT, ${f.m2.multiplier > 1 ? `×${f.m2.multiplier} after sunset in India` : "daytime in India"}`
    );
    // Group sites that got the same level for the same reason, rescue zones first.
    const groups = [];
    for (const a of [...st.alerts].sort((x, y) => (x.site.kind === "disaster" ? 0 : 1) - (y.site.kind === "disaster" ? 0 : 1))) {
      const key = `${a.site.kind}|${a.alert.id}|${a.alert.rule}`;
      let g = groups.find((x) => x.key === key);
      if (!g) groups.push((g = { key, a, sites: [] }));
      g.sites.push(a.site);
    }
    const row = (g) => {
      const kind = g.a.site.kind === "disaster" ? "rescue zone" : "reference receiver";
      const title = g.sites.length > 1 ? `${g.sites.length} ${kind}s` : g.sites[0].name;
      const names = g.sites.length > 1 ? `<span class="rule">${g.sites.map((x) => x.name).join(", ")}</span>` : "";
      return `<div class="decision" style="--c:${STATUS_VAR[g.a.alert.status]}">${chip(g.a.alert)}<span class="name">${title}</span>${names}<span class="act">${g.a.alert.action}</span><span class="rule">Why: ${g.a.alert.rule}</span></div>`;
    };
    this.set("decisions", groups.map(row).join(""));
  }
}
