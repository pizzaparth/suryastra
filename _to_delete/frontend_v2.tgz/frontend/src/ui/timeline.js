// Master timeline: play/pause, speed, scrubbing, chapter bands and event markers.
import { CHAPTERS, SEGMENTS, EVENTS, H_END, ZOOM, timeAt } from "../engine/story.js";

const PLAY = `<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 1.5v13l11-6.5z"/></svg>`;
const PAUSE = `<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 1.5h3.5v13H3zM9.5 1.5H13v13H9.5z"/></svg>`;
const pct = (h) => `${(h / H_END) * 100}%`;
const EV_CLASS = ["", "alertev", "stormev", "minev"];

export class Timeline {
  constructor(root, playback) {
    this.pb = playback;
    const bandRange = (n) => {
      const segs = SEGMENTS.filter((s) => s.chapter === n);
      return [Math.min(...segs.map((s) => s.from)), Math.max(...segs.map((s) => s.to))];
    };
    const ticks = [];
    for (let h = 0; h <= H_END; h++) {
      const d = timeAt(h);
      const hr = d.getUTCHours();
      if (hr === 0) ticks.push(`<span class="day" style="left:${pct(h)}">11 May</span>`);
      else if (hr % 3 === 0) ticks.push(`<span style="left:${pct(h)}">${String(hr).padStart(2, "0")}:00</span>`);
    }
    root.innerHTML = `
      <div class="controls">
        <button class="play" id="play" aria-label="Play">${PLAY}<span>Play</span></button>
        <div class="speeds" role="group" aria-label="Playback speed">
          ${[1, 5, 20].map((s) => `<button data-speed="${s}" aria-pressed="${s === 1}">${s}×</button>`).join("")}
        </div>
      </div>
      <div class="track-area">
        <div class="bands">
          ${CHAPTERS.map((c, i) => {
            const [a, b] = bandRange(c.n);
            return `<button class="band" data-ch="${c.n}" style="left:${pct(a)};width:calc(${pct(b - a)});top:${i * 16}px">${c.n}. ${c.title}</button>`;
          }).join("")}
        </div>
        <div class="zoomlens" id="zoomlens" style="opacity:0">
          <div class="lbl"><span>Zoomed in: <b id="zl-time">02:00:00</b> UTC</span><span>30-second steps, 02:00–02:30</span></div>
          <div class="bar"><div class="fill" id="zl-fill"></div><div class="steps"></div></div>
        </div>
        <div class="track" id="track" role="slider" tabindex="0" aria-label="Storm timeline" aria-valuemin="0" aria-valuemax="${H_END}">
          <div class="rail"></div>
          <div class="done" id="done"></div>
          <div class="zoomwin" style="left:${pct(ZOOM.from)};width:max(6px, ${pct(ZOOM.to - ZOOM.from)})"></div>
          <div class="head" id="head"></div>
        </div>
        <div class="events">
          ${EVENTS.map((e, i) => `<i class="${EV_CLASS[i]}" style="left:${pct(e.h)}" title="${e.label}"></i>`).join("")}
        </div>
        <div class="ticks">${ticks.join("")}</div>
        <ul class="evkey">${EVENTS.map((e, i) => `<li><i class="${EV_CLASS[i]}"></i>${e.label}</li>`).join("")}</ul>
      </div>`;
    this.root = root;
    this.playBtn = root.querySelector("#play");
    this.head = root.querySelector("#head");
    this.done = root.querySelector("#done");
    this.track = root.querySelector("#track");
    this.lens = root.querySelector("#zoomlens");

    this.playBtn.addEventListener("click", () => playback.toggle());
    root.querySelectorAll("[data-speed]").forEach((b) =>
      b.addEventListener("click", () => {
        playback.setSpeed(Number(b.dataset.speed));
        root.querySelectorAll("[data-speed]").forEach((x) => x.setAttribute("aria-pressed", x === b));
      })
    );
    root.querySelectorAll(".band").forEach((b) => b.addEventListener("click", () => playback.goChapter(Number(b.dataset.ch))));

    const scrubTo = (e) => {
      const r = this.track.getBoundingClientRect();
      playback.scrub(((e.clientX - r.left) / r.width) * H_END);
    };
    let dragging = false;
    this.track.addEventListener("pointerdown", (e) => {
      dragging = true;
      this.track.setPointerCapture(e.pointerId);
      scrubTo(e);
    });
    this.track.addEventListener("pointermove", (e) => dragging && scrubTo(e));
    this.track.addEventListener("pointerup", () => (dragging = false));
    this.track.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") playback.scrub(playback.h + 0.25);
      if (e.key === "ArrowLeft") playback.scrub(playback.h - 0.25);
    });
  }

  update(st) {
    this.head.style.left = pct(st.h);
    this.done.style.width = pct(st.h);
    this.track.setAttribute("aria-valuenow", st.h.toFixed(2));
    this.track.setAttribute("aria-valuetext", `${timeAt(st.h).toISOString().slice(11, 16)} UTC`);
    const playing = this.pb.playing;
    if (this.playing !== playing) {
      this.playing = playing;
      this.playBtn.innerHTML = `${playing ? PAUSE : PLAY}<span>${playing ? "Pause" : "Play"}</span>`;
      this.playBtn.setAttribute("aria-label", playing ? "Pause" : "Play");
    }
    this.root.querySelectorAll(".band").forEach((b) => b.setAttribute("aria-current", Number(b.dataset.ch) === st.chapter));
    this.lens.style.opacity = st.zoom ? 1 : 0;
    if (st.zoom) {
      const f = (st.h - ZOOM.from) / (ZOOM.to - ZOOM.from);
      this.root.querySelector("#zl-fill").style.width = `${f * 100}%`;
      const t = timeAt(st.h);
      const step = Math.floor((t.getUTCSeconds() + t.getUTCMinutes() * 60) / 30) * 30;
      const snapped = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate(), t.getUTCHours(), 0, step));
      this.root.querySelector("#zl-time").textContent = snapped.toISOString().slice(11, 19);
    }
  }
}
