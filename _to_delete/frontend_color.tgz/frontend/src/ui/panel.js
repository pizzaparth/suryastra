// Side panel: Dst chart that stays across chapters, plus a few key numbers per chapter.
import { scenario, H_END, timeAt, forecastAt, ZOOM } from "../engine/story.js";
import { ALERT_LEVELS } from "../engine/alerts.js";
import { dstChart, gnssChart } from "./charts.js";

const hhmm = (d) => d.toISOString().slice(11, 16);
const fmtH = (h) => hhmm(timeAt(h));
const nt = (v) => `${v > 0 ? "+" : ""}${Math.round(v)}`.replace("-", "−");
const num = (v, d) => v.toFixed(d).replace("-", "−");
const level = (a) => `<span class="level" data-status="${a.status}">${a.label}</span>`;
const row = (k, id) => `<div class="row"><span class="k">${k}</span><span class="v" id="${id}">–</span></div>`;

export class Panel {
  constructor(root) {
    this.root = root;
    root.innerHTML = `
      <section class="block" id="dst-block">
        <div class="block-head"><h3>Dst index (nT)</h3>
          <div class="key"><span><i></i>Observed</span><span id="key-fc"><i class="dash"></i>Forecast</span></div>
        </div>
        <div class="chart-wrap"><canvas id="dst-chart" role="img" aria-label="Dst index, observed and forecast"></canvas></div>
      </section>
      <div id="chapter-block"></div>`;
    this.chapterEl = root.querySelector("#chapter-block");
    this.dst = dstChart(root.querySelector("#dst-chart"), { xMax: H_END, fmtX: (v) => fmtH(v) });
    this.mode = null;
    this.last = 0;
  }

  build(mode) {
    this.mode = mode;
    this.root.dataset.ch = mode;
    this.gnss?.destroy();
    this.gnss = null;
    this.chapterEl.innerHTML = mode === 1 ? this.ch1() : mode === 2 ? this.ch2() : this.ch3();
    if (mode === 3) {
      const ys = scenario.gnss.series.flatMap((s) => [s.c3_obs, s.c3_pred, s.c3_persistence]);
      this.gnss = gnssChart(this.chapterEl.querySelector("#gnss-chart"), {
        xMax: scenario.gnss.series.length + scenario.gnss.horizon_steps,
        fmtX: (k) => new Date(Date.parse(scenario.gnss.window_start) + k * 30e3).toISOString().slice(11, 16),
        yMin: Math.floor((Math.min(...ys) - 0.03) * 10) / 10,
        yMax: Math.ceil((Math.max(...ys) + 0.03) * 10) / 10,
      });
    }
    this.root.scrollTop = 0;
  }

  ch1() {
    return `
      <section class="block">
        <h3>Solar wind</h3>
        <div class="rows">
          ${row("CME arrival", "v-cme")}
          ${row("Speed", "v-speed")}
          ${row("Bz", "v-bz")}
          ${row("Density", "v-n")}
          ${row("Pressure", "v-p")}
        </div>
      </section>
      <section class="block">
        <h3>Earth</h3>
        <div class="rows">
          ${row("Dst", "v-dst")}
          ${row("Magnetopause", "v-mp")}
        </div>
      </section>`;
  }

  ch2() {
    const m = scenario.m1_metrics;
    return `
      <section class="block">
        <h3>Storm forecast, 1 hour ahead</h3>
        <div class="rows">
          <div class="row"><span class="k" id="fc-k">Forecast</span><span class="v big" id="fc-v">–</span></div>
          ${row("Observed now", "fc-obs")}
          ${row("First red alert", "fc-first")}
        </div>
      </section>
      <section class="block">
        <h3>Alerts issued</h3>
        <div class="rows" id="alert-counts"></div>
      </section>
      <section class="block">
        <h3>Error vs persistence</h3>
        <div class="rows">
          <div class="row"><span class="k">Storm hours, test set</span><span class="v">${num(m.test_storm_hours.mae_nt, 1)} vs ${num(m.persistence_storm_hours.mae_nt, 1)} nT</span></div>
          <div class="row"><span class="k">This storm</span><span class="v">${num(m.may2024_window.model.mae_nt, 1)} vs ${num(m.may2024_window.persistence.mae_nt, 1)} nT</span></div>
        </div>
      </section>`;
  }

  ch3() {
    const g = scenario.gnss.metrics;
    return `
      <section class="block">
        <div class="block-head"><h3>Station error (m)</h3>
          <div class="key"><span><i></i>Obs.</span><span><i class="dash"></i>Model</span><span><i class="dash dim"></i>Persist.</span></div>
        </div>
        <div class="chart-wrap small"><canvas id="gnss-chart" role="img" aria-label="Station error: observed, model forecast and persistence"></canvas></div>
        <div class="rows">
          <div class="row"><span class="k">Error vs persistence</span><span class="v">${num(g.lgbm_mae_m, 3)} vs ${num(g.persistence_mae_m, 3)} m</span></div>
        </div>
      </section>
      <section class="block">
        <h3>NavIC error over India</h3>
        <div class="rows">
          <div class="row"><span class="k" id="m2-k">Forecast</span><span class="v big" id="m2-v">–</span></div>
        </div>
      </section>
      <section class="block">
        <h3>Alerts</h3>
        <div id="decisions"></div>
      </section>`;
  }

  set(id, html) {
    const el = this.chapterEl.querySelector(`#${id}`);
    if (el && el.innerHTML !== html) el.innerHTML = html;
  }

  update(st, force = false) {
    const now = performance.now();
    if (!force && now - this.last < 90) return;
    this.last = now;
    if (st.chapter !== this.mode) this.build(st.chapter);
    this.updateDst(st);
    if (st.chapter === 1) this.updateCh1(st);
    if (st.chapter === 2) this.updateCh2(st);
    if (st.chapter === 3) this.updateCh3(st);
  }

  updateDst(st) {
    const obs = [];
    for (let i = 0; i <= Math.floor(st.h); i++) obs.push({ x: i, y: scenario.hourly[i].dst_obs });
    obs.push({ x: st.h, y: st.obs.dst });
    const fc = [];
    if (st.chapter > 1)
      for (let i = 0; i <= Math.min(Math.floor(st.h), H_END - 1); i++) {
        const r = scenario.hourly[i];
        if (r.m1) fc.push({ x: i + 1, y: r.m1.dst_pred });
      }
    this.dst.data.datasets[0].data = obs;
    this.dst.data.datasets[1].data = fc;
    this.dst.options.plugins.overlay.playX = st.h;
    this.dst.update("none");
    this.root.querySelector("#key-fc").style.visibility = st.chapter > 1 ? "visible" : "hidden";
  }

  updateCh1(st) {
    const o = st.obs;
    const dh = st.impactH - st.h;
    const hm = (x) => `${Math.floor(x)}h ${String(Math.floor((x % 1) * 60)).padStart(2, "0")}m`;
    this.set("v-cme", dh > 0 ? `in ${hm(dh)}` : "arrived");
    this.set("v-speed", `${Math.round(o.sw_speed)} km/s`);
    this.set("v-bz", `${num(o.bz, 1)} nT`);
    this.set("v-n", `${num(o.proton_density, 1)} /cm³`);
    this.set("v-p", `${num(o.dyn_pressure, 1)} nPa`);
    this.set("v-dst", `${nt(o.dst)} nT`);
    this.set("v-mp", `${num(st.mp.r0, 1)} Rₑ`);
  }

  updateCh2(st) {
    const f = forecastAt(st.h);
    this.set("fc-k", `For ${fmtH(f.forH)} UTC`);
    this.set("fc-v", `${nt(f.m1.dst_pred)} nT`);
    this.set("fc-obs", `${nt(st.obs.dst)} nT`);
    const firstRed = st.firstRedH;
    this.set("fc-first", firstRed >= 0 && st.h >= firstRed ? `${fmtH(firstRed)} UTC` : "–");
    const counts = {};
    for (const a of st.alerts) counts[a.alert.id] = (counts[a.alert.id] || 0) + 1;
    this.set(
      "alert-counts",
      ALERT_LEVELS.filter((l) => counts[l.id])
        .map((l) => `<div class="row"><span class="k">${level(l)}</span><span class="v">${counts[l.id]} site${counts[l.id] > 1 ? "s" : ""}</span></div>`)
        .join("")
    );
  }

  updateCh3(st) {
    const g = scenario.gnss;
    const k = st.zoom ? (st.h - ZOOM.from) * 120 : g.series.length;
    const n = Math.min(Math.floor(k), g.series.length - 1);
    const obs = [];
    const lg = [];
    const pe = [];
    for (let i = 0; i <= n; i++) {
      const s = g.series[i];
      obs.push({ x: i, y: s.c3_obs });
      lg.push({ x: i + g.horizon_steps, y: s.c3_pred });
      pe.push({ x: i + g.horizon_steps, y: s.c3_persistence });
    }
    if (this.gnss) {
      this.gnss.data.datasets[0].data = obs;
      this.gnss.data.datasets[1].data = lg;
      this.gnss.data.datasets[2].data = pe;
      this.gnss.options.plugins.overlay.playX = st.zoom ? Math.min(k, g.series.length) : null;
      this.gnss.update("none");
    }
    const f = forecastAt(st.h);
    this.set("m2-k", `For ${fmtH(f.forH)} UTC`);
    this.set("m2-v", `${num(f.m2.navic_error_m, 1)} m`);

    // one line per (kind, level): rescue zones first
    const groups = [];
    for (const a of st.alerts) {
      const key = `${a.site.kind}|${a.alert.id}`;
      let g2 = groups.find((x) => x.key === key);
      if (!g2) groups.push((g2 = { key, a, n: 0 }));
      g2.n++;
    }
    groups.sort((x, y) => (x.a.site.kind === "disaster" ? -1 : 1) - (y.a.site.kind === "disaster" ? -1 : 1));
    this.set(
      "decisions",
      groups
        .map((g2) => {
          const what = g2.a.site.kind === "disaster" ? "rescue zone" : "receiver";
          const who = g2.n > 1 ? `${g2.n} ${what}s` : g2.a.site.name;
          return `<div class="decision"><div class="top-line">${level(g2.a.alert)}<span>${who}</span></div><div class="act">${g2.a.alert.action}</div></div>`;
        })
        .join("")
    );
  }
}
