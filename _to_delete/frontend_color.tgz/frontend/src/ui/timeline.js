// Master timeline: play/pause, speed, scrubbing, chapter bands.
import { CHAPTERS, SEGMENTS, H_END } from "../engine/story.js";

const pct = (h) => `${(h / H_END) * 100}%`;

export class Timeline {
  constructor(root, playback) {
    this.pb = playback;
    // each chapter band starts where that chapter starts and ends where the next one starts
    const starts = CHAPTERS.map((c) => SEGMENTS.find((s) => s.chapter === c.n).from);
    root.innerHTML = `
      <div class="controls">
        <button class="btn primary" id="play">Play</button>
        ${[1, 5, 20].map((s) => `<button class="btn" data-speed="${s}" aria-pressed="${s === 1}">${s}×</button>`).join("")}
      </div>
      <div class="track-area">
        <div class="bands">
          ${CHAPTERS.map((c, i) => {
            const a = starts[i];
            const b = i < starts.length - 1 ? Math.max(starts[i + 1], a + 4) : H_END;
            return `<button class="band" data-ch="${c.n}" style="left:${pct(a)};width:${pct(b - a)}">${c.n}. ${c.title}</button>`;
          }).join("")}
        </div>
        <div class="track" id="track" role="slider" tabindex="0" aria-label="Storm timeline" aria-valuemin="0" aria-valuemax="${H_END}">
          <div class="rail"></div>
          <div class="done" id="done"></div>
          <div class="head" id="head"></div>
        </div>
      </div>`;
    this.root = root;
    this.playBtn = root.querySelector("#play");
    this.head = root.querySelector("#head");
    this.done = root.querySelector("#done");
    this.track = root.querySelector("#track");

    this.playBtn.addEventListener("click", () => playback.toggle());
    root.querySelectorAll("[data-speed]").forEach((b) =>
      b.addEventListener("click", () => {
        playback.setSpeed(Number(b.dataset.speed));
        root.querySelectorAll("[data-speed]").forEach((x) => x.setAttribute("aria-pressed", x === b));
      })
    );
    root.querySelectorAll(".band").forEach((b) => b.addEventListener("click", () => playback.goChapter(Number(b.dataset.ch))));

    const scrubTo = (e) => {
      const r = this.track.getBoundingClientRect();
      playback.scrub(((e.clientX - r.left) / r.width) * H_END);
    };
    let dragging = false;
    this.track.addEventListener("pointerdown", (e) => {
      dragging = true;
      this.track.setPointerCapture(e.pointerId);
      scrubTo(e);
    });
    this.track.addEventListener("pointermove", (e) => dragging && scrubTo(e));
    this.track.addEventListener("pointerup", () => (dragging = false));
    this.track.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") playback.scrub(playback.h + 0.25);
      if (e.key === "ArrowLeft") playback.scrub(playback.h - 0.25);
    });
  }

  update(st) {
    this.head.style.left = pct(st.h);
    this.done.style.width = pct(st.h);
    this.track.setAttribute("aria-valuenow", st.h.toFixed(2));
    if (this.playing !== this.pb.playing) {
      this.playing = this.pb.playing;
      this.playBtn.textContent = this.playing ? "Pause" : "Play";
    }
    this.root.querySelectorAll(".band").forEach((b) => b.setAttribute("aria-current", Number(b.dataset.ch) === st.chapter));
  }
}
