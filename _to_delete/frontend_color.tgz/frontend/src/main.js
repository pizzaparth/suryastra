import "@fontsource-variable/archivo/wdth.css";
import "./styles.css";
import { StormScene } from "./scene/scene.js";
import { Panel } from "./ui/panel.js";
import { Timeline } from "./ui/timeline.js";
import {
  scenario,
  Playback,
  CHAPTERS,
  IMPACT_H,
  ZOOM,
  timeAt,
  observedAt,
  magnetopause,
  m2Error,
  alertsAt,
  EVENTS,
} from "./engine/story.js";

const $ = (s) => document.querySelector(s);
const hhmm = (d) => d.toISOString().slice(11, 16);

const scene = new StormScene($("#scene"), $("#labels"));
scene.setSites(scenario.sites);
const panel = new Panel($("#panel"));
const pb = new Playback();
const timeline = new Timeline($("#timeline"), pb);

window.addEventListener("resize", () => scene.resize());
window.addEventListener("keydown", (e) => {
  if (e.code === "Space" && e.target === document.body) {
    e.preventDefault();
    pb.toggle();
  }
});

// ---------- caption and transition flash ----------
function setCaption(n) {
  const c = CHAPTERS[n - 1];
  $("#caption").innerHTML = `<div class="num">${c.n} / 3</div><h2>${c.title}</h2>`;
}

function flash(title) {
  const el = $("#flash");
  el.hidden = false;
  el.innerHTML = `<span>${title}</span>`;
  el.style.animation = "none";
  void el.offsetWidth;
  el.style.animation = "";
  clearTimeout(flash.t);
  flash.t = setTimeout(() => (el.hidden = true), 2500);
}

pb.on((type, p) => {
  if (type === "chapter") {
    scene.resetView();
    setCaption(p.chapter);
    if (p.chapter === 2 && p.playing) flash("Rewind to 17:00 UTC");
    if (p.chapter === 3 && p.playing) flash("Zoom in: 30-second steps");
    panel.update(state(), true);
  }
  if (type === "segment" && !p.zoom) flash("Zoom out");
});
setCaption(1);

// ---------- state for one frame ----------
function state(dt = 0) {
  const h = pb.h;
  const date = timeAt(h);
  const obs = observedAt(h);
  const mp = magnetopause(obs.dyn_pressure, obs.bz);
  const storm = Math.min(1, Math.max(0, (-obs.dst - 15) / 330));
  return {
    h,
    dt,
    date,
    chapter: pb.chapter,
    zoom: pb.zoom,
    obs,
    mp,
    storm,
    impactH: IMPACT_H,
    truthError: m2Error(obs.dst, date),
    alerts: pb.chapter > 1 ? alertsAt(h) : null,
    focusSite: pb.chapter === 3 && pb.zoom ? scenario.gnss.display_station : null,
    snap: snapFrames > 0,
    firstRedH: EVENTS[1].h,
  };
}

let snapFrames = 0;
let last = performance.now();
let lastClock = "";
function frame(now) {
  const dt = (now - last) / 1000;
  last = now;
  pb.tick(dt);
  const st = state(dt);
  if (snapFrames > 0) snapFrames--;
  scene.update(st);
  if (pb.chapter > 1) panel.update(st);
  else panel.update({ ...st, alerts: [] });
  timeline.update(st);
  const z = pb.zoom;
  const clock = `${st.date.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" })}, ${z ? new Date(Math.floor(st.date.getTime() / 30e3) * 30e3).toISOString().slice(11, 19) : hhmm(st.date)} UTC`;
  if (clock !== lastClock) {
    lastClock = clock;
    $("#clock").textContent = clock;
  }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// for quick checks from the console / screenshots: ?h=7&ch=2
const q = new URLSearchParams(location.search);
if (q.has("ch")) pb.goChapter(Number(q.get("ch")));
if (q.has("h")) pb.scrub(Number(q.get("h")));
if (q.has("ch") || q.has("h")) snapFrames = 8;
if (q.has("play")) pb.toggle();
window.__pb = pb;
void ZOOM;
